# Configurazione per eseguire test selettivo di un singolo modulo.

1. Disabilitato javaDoc, per bug
2. Usato e installato jdk 11
3. Sovrastitto maven surefire nel modulo d'interesse con la versione 3.0.M..
   per far coesistere test in junit e test in jupiter, vedi pom del modulo:
   syncope-common-am-lib.
4. Aggiunto flag di compilazione "11" al maven-compiler-plugin altrimenti non possibile
   effettuare test in locale. Vedi pom.xml.
5. Eventuale compilazione totale con:
   `mvn -U -T 1C -P skipTests,all`

6. Usando:
   `mvn -pl .,common/am/lib -U -T 1C verify -Dtest=org.apache.syncope.common.lib.*Test -Dinvoker.streamLogs=true -Dmodernizer.skip=true -Dianal.skip=true -Drat.skip=true -Dcheckstyle.skip=true -Dsass.skip=true -DfailIfNoTests=false`

   Si eseguono i test del modulo lib (sottomodulo di am, sottomodulo di common), 
   compilando solo i moduli dipendenti neceddari.

# Jacoco

Già funzionante usando il comando di sopra genera il report nella cartella target del modulo

# Pit

Usare soluzione di bookkeeper